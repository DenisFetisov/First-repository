
function guess() {
    var num = prompt('Введите число')
    if (num > 5) {
        alert('Число должно быть меньше')
        return guess()
    } else if (num == 5) {
        return alert("Угадал")

    } else {
        alert('Число должно быть больше')
        return guess()
    }
}


alert("hello js")
alert("уъуъ джаваскрипт")
guess()
