function guess() {
    var num = prompt('Введите число')
    if (num > 5) {
        alert('Число должно быть меньше')
        return guess()
    } else if (num == 5) {
        return alert("Угадал")

    } else {
        alert('Число должно быть больше')
        return guess()
    }
}


//guess()

function timer() {
    alert("Вы спите?")
}

//setTimeout(timer, 3000)

function valid() {
    var name = document.getElementById('name').value
    var password = document.getElementById('password').value
    
    var reg_name = /^[а-яa-zё]+$/i
    var reg_password = /^[a-z0-9]{5, 100}/i
    
    if (reg_name.test(name) == false) {
        alert('ФИО введено некорректно')
    }
        if (reg_password.test(password) == false) {
        alert('Пароль введен некорректно. Допустимы только английские буквы, цифры. Длина пароля должна быть не менее 5 и не более 100 символов')
    }
}

document.querySelector('.button').addEventListener('click', valid)