function valid() {
    var num1 = document.getElementById('num1').value;
    var operator = document.getElementById('operator').value;
    
    alert(num1);
    var reg_num = /^[a-z0-9]+$/;
    //var reg_base = /^[0-9]{2, 36}+/;
    var reg_operator = /^[\+\-\*\/]/;
    
    if (reg_num.test(num1) == false) {
        alert('Число введено некорректно');
    }
        if (reg_operator.test(operator) == false) {
        alert('Оператор введен некорректно.');
    }
}


//function todo() {
//    var number = document.getElementById('num1').value;
//    alert(number);
//}

document.querySelector('.button').addEventListener('click', valid)
//document.querySelector('.button').addEventListener('click', todo)