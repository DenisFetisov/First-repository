num1 = prompt('Введите первое число')
оperator = prompt('Введите оператор')
num2 = prompt('Введите второе число')
if (operator == '+') {}
       //alert(num1 + num2)
//alert(num1 + num2)
alert("1")